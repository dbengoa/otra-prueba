# Comparar NDVI de Sentinel-2 desde un clic en QGIS

Complemento NDVI Sentinel 0.1.4. Pensado para QGIS 3.22–3.x con GDAL 3 y NumPy,
disponibles normalmente en la instalación de QGIS. No necesitas Sentinel Hub
ni proporcionar una clave de API: consulta el catálogo público Earth Search
de Element 84, colección `sentinel-2-l2a`, y lee sus imágenes COG por HTTPS.

## Uso

1. Abre un proyecto de QGIS y sitúa el mapa en la zona de interés.
2. Instala `ndvi_sentinel.zip` desde **Complementos → Administrar e instalar complementos → Instalar a partir de ZIP**.
3. Activa **NDVI Sentinel** y pulsa su botón de la barra de herramientas o **Complementos → NDVI Sentinel → Comparar NDVI Sentinel-2**.
4. Haz clic en el mapa. Aparecerá el diálogo de configuración.
5. Selecciona dos intervalos cronológicos que no se solapen, el número de
   imágenes de cada intervalo, el radio y una carpeta de resultados.
6. Acepta. El análisis se ejecuta en segundo plano y permite cancelar.

El radio inicial es 1 km, configurable entre 50 m y 5 km. Las fechas finales
son inclusivas y se consultan como días UTC del catálogo. Para abandonar la
herramienta, selecciona la herramienta habitual de desplazamiento del mapa.

## Qué calcula

- Busca escenas con **nubosidad de catálogo ≤20 %**.
- Lee rojo B04, infrarrojo cercano B08 y clasificación SCL.
- Reproyecta las bandas a una cuadrícula común UTM de 10 m. Usa interpolación
  bilineal para las bandas espectrales y vecino más próximo para SCL.
- Aplica la escala y el offset radiométricos. Esto evita errores al comparar
  imágenes anteriores y posteriores al cambio de baseline de Sentinel-2.
- Solo acepta píxeles SCL de vegetación, suelo sin vegetación o agua (4, 5, 6).
  Excluye nubes, cirros, sombras, nieve, píxeles sin clasificar y no-data.
- El **mínimo de área válida dentro del círculo** es un filtro adicional
  configurable de 0 a 100 %, desactivado inicialmente. No se confunde con
  el requisito de un 80 % libre de nubes de la escena completa. Aunque esté
  desactivado, siempre excluye los píxeles no válidos y exige algún dato válido.
- Calcula `NDVI = (B08 − B04) / (B08 + B04)` para cada imagen y después toma la
  mediana por píxel de las imágenes de cada intervalo.
- Calcula `cambio = NDVI_segundo_intervalo − NDVI_primer_intervalo` únicamente
  donde ambos resultados tienen datos válidos.

Selecciona primero las escenas más próximas al centro de cada intervalo;
en caso de empate, prioriza menor nubosidad. No cuenta varias teselas del
mismo paso como varias adquisiciones. Evalúa como máximo 50 candidatas por
intervalo. Si no logra reunir exactamente las imágenes solicitadas, muestra
un error; no reduce silenciosamente el número ni relaja el filtro de nubes.
Si rechaza escenas por falta de cobertura válida, muestra sus porcentajes
de NDVI válido, SCL despejado y bandas espectrales válidas.

## Actualizar desde una versión anterior

Desinstala NDVI Sentinel desde el administrador de complementos, instala el
ZIP 0.1.4 y reinicia QGIS para descargar de memoria los módulos anteriores.
El aviso de intervalos solapados se resuelve haciendo que el segundo intervalo
comience después del último día del primero.

## Resultados

Cada ejecución crea una subcarpeta nueva y no sobrescribe resultados:

- `ndvi_1.tif` y `ndvi_2.tif`: NDVI compuesto de cada intervalo.
- `cambio_ndvi.tif`: diferencia. Rojo indica descenso y verde aumento.
- `observaciones_1.tif` y `observaciones_2.tif`: número de imágenes válidas
  por píxel utilizadas para cada compuesto, para revisar su soporte temporal.
- `metadatos.json`: parámetros, escenas y fechas reales, enlaces de origen,
  filtros, correcciones radiométricas y estadísticas de cambio.

Los GeoTIFF se añaden al proyecto. Fuera del círculo y donde no hay datos
válidos se utiliza no-data. Las zonas restantes pueden tener menos del
número solicitado de observaciones por píxel: consulta las capas de recuento.

## Límites y acceso

Necesita acceso HTTPS a `earth-search.aws.element84.com` y a los destinos de
los assets que devuelva el catálogo, habitualmente los buckets públicos
Sentinel en Amazon S3. Mantiene la verificación TLS. Si falla, consulta el
panel **Mensajes de registro**, pestaña **NDVI Sentinel**, para ver el detalle.

El 80 % es un criterio basado en metadatos y clasificación automática, no una
garantía visual absoluta. Una bajada de NDVI puede deberse a estacionalidad,
cosecha, humedad o diferencias de observación; el resultado mide el cambio
del índice, no clasifica automáticamente una pérdida de vegetación.

Se ha validado en QGIS 3.40 y GDAL 3.10: lectura/reproyección de bandas,
GeoTIFF, simbología y tareas consecutivas con datos de ensayo. La reparación
se ha probado con los diagnósticos reales aportados por el usuario, sin
modificar los originales. La descarga remota de Sentinel no se ha ejecutado
en este entorno porque el acceso al catálogo está bloqueado.

## Cambios de 0.1.2

Protege las referencias a tareas eliminadas por QGIS, desconecta el diálogo
al finalizar y descarta señales tardías de análisis anteriores. Evita el
error `wrapped C/C++ object of type NDVITask has been deleted`.

## Diagnóstico del bosque (0.1.3)

No se considera confirmada la causa de los huecos a partir de una captura.
La versión 0.1.3 no deduce un offset faltante del baseline 04.00 o posterior:
exige el offset del asset/GDAL o una declaración de que ya se aplicó al COG.
Esto evita una corrección supuesta en archivos potencialmente armonizados.

Guarda capas `diagnostico_periodo*_SCL.tif`, `*_rojo.tif`, `*_NIR.tif` y
`*_exclusion.tif` para la primera candidata y cada imagen aceptada.
Las bandas rojo/NIR contienen la reflectancia aplicada, no los DN originales.
Las capas de exclusión se añaden desactivadas al proyecto con una leyenda:

- 1: NDVI válido.
- 2: falta de cobertura/datos de banda.
- 3: SCL sin datos o píxel defectuoso.
- 4: zona oscura/sombra topográfica (SCL 2).
- 5: sombra de nube (SCL 3).
- 6: sin clasificar (SCL 7).
- 7: nube/cirro (SCL 8, 9 o 10).
- 8: nieve/hielo (SCL 11).
- 9: reflectancia negativa del rojo o NIR en píxel SCL despejado.
- 10: denominador o NDVI inválido.
- 11: clase SCL no reconocida.

Activa una capa `*_exclusion` y usa Identificar en el pinar. Si devuelve 4,
el bosque está enmascarado por SCL 2; si devuelve 9, hay reflectancia negativa
que requiere revisar sus metadatos radiométricos. No se incluyen sombras
ni se rellenan huecos para conseguir artificialmente un NDVI completo.
`metadatos.json` incluye porcentajes por causa y metadatos de escala/offset.
Si el análisis falla después de generar diagnóstico, conserva esas capas y
`diagnostico_error.json`; una cancelación elimina los resultados parciales.

## Corrección confirmada y reparación sin descarga (0.1.4)

Cuando `earthsearch:boa_offset_applied` es verdadero, los assets COG TIFF ya
están corregidos. El complemento no vuelve a aplicar su offset aunque el
asset conserve `offset=-0.1` del producto original. Para JP2 o COG sin esa
marca, conserva el offset declarado. La máscara SCL de nubes y sombras
permanece activa.

Se confirmó con archivos del usuario: el rojo del bosque se había vuelto
negativo por una segunda resta de 0.1. Tras corregirlo, el primer periodo
recuperó el 100 % del área de análisis y el segundo el 98.8 %; los huecos
restantes corresponden a las exclusiones de calidad.

Para recuperar tus resultados sin consultar de nuevo Sentinel:

1. Instala 0.1.4 y reinicia QGIS.
2. Ve a **Complementos → NDVI Sentinel → Reparar resultados guardados…**.
3. Selecciona `metadatos.json` de la carpeta original, que debe conservar
   los archivos `diagnostico_*_rojo.tif`, `*_NIR.tif` y `*_SCL.tif`.
4. Se crea una subcarpeta `NDVI_reparado_*`, se recalcula NDVI y cambio y se
   añaden las nuevas capas al proyecto. Retira u oculta las capas antiguas.

Los originales quedan intactos. Usa únicamente las escenas seleccionadas
para el compuesto original; conserva el número de observaciones por periodo.
La reparación es repetible: no añade de nuevo el offset a archivos reparados.
