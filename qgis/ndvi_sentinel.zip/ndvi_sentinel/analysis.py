"""QGIS 3: comparar NDVI Sentinel-2 L2A alrededor de un punto.

Motor de análisis del complemento NDVI Sentinel.
Requiere numpy y GDAL (incluidos normalmente en QGIS) y acceso HTTPS a
earth-search.aws.element84.com y a los archivos COG indicados por su catálogo.
No requiere una cuenta de Sentinel Hub ni modifica las capas de entrada.
"""

import json
import math
import shutil
import traceback
import uuid
from functools import partial
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import urljoin, urlparse
from urllib.request import Request, urlopen

import numpy as np
from osgeo import gdal, osr
from qgis.PyQt import sip
from qgis.PyQt.QtCore import QDate, Qt, pyqtSignal
from qgis.PyQt.QtWidgets import (
    QDialog, QDialogButtonBox, QDateEdit, QFileDialog, QFormLayout,
    QHBoxLayout, QLabel, QLineEdit, QPushButton, QSpinBox, QProgressDialog,
)
from qgis.core import (
    Qgis, QgsApplication, QgsColorRampShader, QgsCoordinateReferenceSystem,
    QgsCoordinateTransform, QgsProject, QgsRasterLayer, QgsRasterShader,
    QgsSingleBandPseudoColorRenderer, QgsTask,
)
from qgis.gui import QgsMapToolEmitPoint
from qgis.PyQt.QtGui import QColor
from qgis.utils import iface


STAC_URL = "https://earth-search.aws.element84.com/v1/search"
COLLECTION = "sentinel-2-l2a"
RESOLUTION = 10
MAX_CANDIDATES = 50
MAX_ITEMS = 2000
CLEAR_SCL = (4, 5, 6)  # Vegetación, suelo sin vegetación y agua.
EXCLUSION_LABELS = {
    1: "NDVI válido", 2: "Sin cobertura o datos de banda",
    3: "SCL sin datos o píxel defectuoso", 4: "SCL 2: zona oscura/sombra topográfica",
    5: "SCL 3: sombra de nube", 6: "SCL 7: sin clasificar",
    7: "SCL 8/9/10: nube o cirro", 8: "SCL 11: nieve/hielo",
    9: "Reflectancia negativa en rojo o NIR", 10: "Denominador o NDVI inválido",
    11: "Clase SCL no reconocida",
}


def exclusion_map(red, nir, scl, aoi):
    """Explica la exclusión, sin rellenar huecos ni cambiar la máscara."""
    result = np.full(red.shape, np.nan, dtype=np.float32)
    result[aoi] = 11
    result[aoi & np.isin(scl, CLEAR_SCL)] = 10
    result[aoi & np.isin(scl, CLEAR_SCL) & ((red < 0) | (nir < 0))] = 9
    for classes, code in [((0, 1), 3), ((2,), 4), ((3,), 5), ((7,), 6),
                          ((8, 9, 10), 7), ((11,), 8)]:
        result[aoi & np.isin(scl, classes)] = code
    result[aoi & (~np.isfinite(red) | ~np.isfinite(nir) | ~np.isfinite(scl))] = 2
    result[np.isfinite(compute_ndvi(red, nir, scl, aoi))] = 1
    return result


def exclusion_summary(codes, aoi):
    total = int(np.count_nonzero(aoi))
    return {str(code): {"label": label,
                        "percent": float(100 * np.count_nonzero(codes == code) / total)}
            for code, label in EXCLUSION_LABELS.items()}


def acquisition_key(item):
    properties = item["properties"]
    datatake = properties.get("s2:datatake_id")
    if datatake:
        return str(datatake)
    # No contar varias teselas del mismo paso como varias imágenes temporales.
    return "%s/%s/%s" % (properties.get("platform", "sentinel-2"),
                          properties["datetime"][:10],
                          properties.get("sat:relative_orbit", ""))


def compute_ndvi(red, nir, scl, aoi):
    """Excluye nubes, sombras, nieve, no-data y valores espectrales inválidos."""
    denominator = nir + red
    valid = (
        aoi & np.isin(scl, CLEAR_SCL) & np.isfinite(red) & np.isfinite(nir)
        & (red >= 0) & (nir >= 0) & (denominator > 0)
    )
    result = np.full(red.shape, np.nan, dtype=np.float32)
    np.divide(nir - red, denominator, out=result, where=valid)
    valid &= np.isfinite(result) & (result >= -1) & (result <= 1)
    result[~valid] = np.nan
    return result


def median_composite(images):
    """Mediana por píxel, sin avisos por zonas completamente enmascaradas."""
    stack = np.stack(images)
    available = np.any(np.isfinite(stack), axis=0)
    result = np.full(stack.shape[1:], np.nan, dtype=np.float32)
    result[available] = np.nanmedian(stack[:, available], axis=0)
    counts = np.sum(np.isfinite(stack), axis=0).astype(np.float32)
    return result, counts


def date_window(start_date, end_date):
    start = datetime.strptime(start_date, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    end = datetime.strptime(end_date, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    end += timedelta(days=1) - timedelta(seconds=1)
    if end < start:
        raise ValueError("El final del intervalo debe ser posterior o igual al inicio.")
    center = start + (end - start) / 2
    return center, start.isoformat(), end.isoformat()


def request_json(url, method="GET", body=None):
    if urlparse(url).scheme != "https":
        raise ValueError("El catálogo debe usar HTTPS.")
    payload = None if body is None else json.dumps(body).encode("utf-8")
    request = Request(url, data=payload, method=method, headers={
        "Accept": "application/geo+json, application/json",
        "Content-Type": "application/json",
        "User-Agent": "QGIS-NDVI-comparison/1.0",
    })
    with urlopen(request, timeout=60) as response:
        return json.load(response)


def search_items(polygon, start_date, end_date, check_cancel):
    center, start, end = date_window(start_date, end_date)
    body = {
        "collections": [COLLECTION], "intersects": polygon,
        "datetime": start + "/" + end,
        "query": {"eo:cloud_cover": {"lte": 20}}, "limit": 100,
    }
    url, method, seen, items = STAC_URL, "POST", set(), []
    for _ in range(40):
        check_cancel()
        response = request_json(url, method, body)
        for item in response.get("features", []):
            item_id = item["id"]
            properties = item.get("properties", {})
            cloud = properties.get("eo:cloud_cover")
            # Un metadato ausente nunca equivale a cielo despejado.
            if item_id in seen or cloud is None or not (0 <= float(cloud) <= 20):
                continue
            seen.add(item_id)
            items.append(item)
        if len(items) > MAX_ITEMS:
            raise RuntimeError("Demasiadas escenas. Reduce el radio o la ventana temporal.")
        next_link = next((link for link in response.get("links", [])
                          if link.get("rel") == "next"), None)
        if next_link is None:
            break
        url = urljoin(url, next_link["href"])
        method = next_link.get("method", "GET").upper()
        next_body = next_link.get("body")
        if method == "POST" and next_link.get("merge"):
            body = dict(body or {}, **(next_body or {}))
        else:
            body = next_body if method == "POST" else None
    else:
        raise RuntimeError("La búsqueda supera el límite de páginas. Reduce la ventana.")

    def order(item):
        properties = item["properties"]
        instant = datetime.fromisoformat(properties["datetime"].replace("Z", "+00:00"))
        return abs((instant - center).total_seconds()), float(properties["eo:cloud_cover"])

    return sorted(items, key=order)


def make_grid(lon, lat, radius):
    if not (-80 <= lat <= 84):
        raise ValueError("El punto está fuera del intervalo de Sentinel-2/UTM.")
    zone = min(60, max(1, int((lon + 180) // 6) + 1))
    epsg = (32600 if lat >= 0 else 32700) + zone
    geographic, projected = osr.SpatialReference(), osr.SpatialReference()
    geographic.ImportFromEPSG(4326)
    projected.ImportFromEPSG(epsg)
    for crs in (geographic, projected):
        crs.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
    to_utm = osr.CoordinateTransformation(geographic, projected)
    to_geo = osr.CoordinateTransformation(projected, geographic)
    x, y, _ = to_utm.TransformPoint(lon, lat)
    size = int(math.ceil(2 * radius / RESOLUTION))
    half = size * RESOLUTION / 2
    bounds = (x - half, y - half, x + half, y + half)
    coordinates = []
    for i in range(64):
        angle = 2 * math.pi * i / 64
        gx, gy, _ = to_geo.TransformPoint(x + radius * math.cos(angle),
                                         y + radius * math.sin(angle))
        coordinates.append([gx, gy])
    coordinates.append(coordinates[0])
    polygon = {"type": "Polygon", "coordinates": [coordinates]}
    cols = bounds[0] + (np.arange(size) + 0.5) * RESOLUTION
    rows = bounds[3] - (np.arange(size) + 0.5) * RESOLUTION
    aoi = (cols[None, :] - x) ** 2 + (rows[:, None] - y) ** 2 <= radius ** 2
    return epsg, bounds, size, polygon, aoi


def get_asset(item, name, band_name):
    assets = item.get("assets", {})
    if name in assets:
        asset = assets[name]
    elif band_name in assets:
        asset = assets[band_name]
    else:
        raise RuntimeError("La escena no proporciona el asset " + name)
    if urlparse(asset.get("href", "")).scheme != "https":
        raise RuntimeError("Se requiere un asset COG con URL HTTPS.")
    return asset


def reflectance_parameters(asset, band, item):
    metadata = (asset.get("raster:bands") or [{}])[0]
    scale = metadata.get("scale", band.GetScale())
    offset = metadata.get("offset", band.GetOffset())
    if scale is None:
        scale = 0.0001  # Factor de cuantificación de Sentinel-2 L2A.
    # Earth Search puede conservar el offset del producto original en el asset
    # aunque haya armonizado el COG. No aplicarlo por segunda vez al TIFF.
    applied = item.get("properties", {}).get("earthsearch:boa_offset_applied")
    path = urlparse(asset.get("href", "")).path.lower()
    is_cog = path.endswith((".tif", ".tiff"))
    if applied is True and is_cog:
        offset = 0.0
    if offset is None:
        properties = item.get("properties", {})
        if properties.get("earthsearch:boa_offset_applied") is True:
            offset = 0
        else:
            baseline = properties.get("s2:processing_baseline")
            if baseline is None:
                raise RuntimeError("Faltan metadatos para corregir el offset radiométrico.")
            if float(baseline) >= 4:
                raise RuntimeError(
                    "El COG no declara offset radiométrico. No se deduce del baseline: "
                    "el proveedor puede haberlo aplicado ya."
                )
            offset = 0
    return float(scale), float(offset)


def stored_offset_correction(info):
    """Corrección de las reflectancias guardadas por versiones anteriores."""
    path = urlparse(info.get("href", "")).path.lower()
    parameters = info.get("scale_offset")
    if info.get("boa_offset_applied") is True and path.endswith((".tif", ".tiff")):
        if parameters is None or len(parameters) != 2:
            raise ValueError("Falta el offset aplicado en los resultados antiguos.")
        return -float(parameters[1])
    return 0.0


def read_asset(item, name, band_name, grid, categorical=False):
    epsg, bounds, size, _, _ = grid
    asset = get_asset(item, name, band_name)
    dataset = gdal.Open("/vsicurl/" + asset["href"], gdal.GA_ReadOnly)
    if dataset is None:
        raise RuntimeError("No se puede leer " + name + " de " + item["id"])
    band = dataset.GetRasterBand(1)
    parameters = None if categorical else reflectance_parameters(asset, band, item)
    nodata = (asset.get("raster:bands") or [{}])[0].get("nodata", band.GetNoDataValue())
    if nodata is None:
        nodata = 0
    warped = gdal.Warp("", dataset, format="MEM", dstSRS="EPSG:" + str(epsg),
                       outputBounds=bounds, width=size, height=size,
                       resampleAlg="near" if categorical else "bilinear",
                       outputType=gdal.GDT_Float32, srcNodata=float(nodata),
                       dstNodata=-9999, multithread=False)
    if warped is None:
        raise RuntimeError("No se pudo reproyectar " + name)
    result = warped.ReadAsArray().astype(np.float32)
    result[result == -9999] = np.nan
    if parameters is not None:
        result = result * parameters[0] + parameters[1]
    return result, {"href": asset["href"], "scale_offset": parameters,
                    "asset_raster_bands": asset.get("raster:bands"),
                    "gdal_scale": band.GetScale(), "gdal_offset": band.GetOffset(),
                    "boa_offset_applied": item.get("properties", {}).get("earthsearch:boa_offset_applied")}


def save_raster(path, array, grid, nodata=-9999):
    epsg, bounds, size, _, _ = grid
    driver = gdal.GetDriverByName("GTiff")
    dataset = driver.Create(str(path), size, size, 1, gdal.GDT_Float32,
                            options=["COMPRESS=DEFLATE", "TILED=YES"])
    if dataset is None:
        raise RuntimeError("No se pudo crear " + str(path))
    crs = osr.SpatialReference()
    crs.ImportFromEPSG(epsg)
    dataset.SetProjection(crs.ExportToWkt())
    dataset.SetGeoTransform((bounds[0], RESOLUTION, 0, bounds[3], 0, -RESOLUTION))
    band = dataset.GetRasterBand(1)
    band.SetNoDataValue(nodata)
    band.WriteArray(np.where(np.isfinite(array), array, nodata))
    dataset.FlushCache()
    dataset = None


def repair_saved_results(metadata_path):
    """Recalcula únicamente las escenas seleccionadas; preserva los originales."""
    metadata_path = Path(metadata_path).resolve()
    folder = metadata_path.parent
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    reference = None
    grid = None
    output = folder / ("NDVI_reparado_" + uuid.uuid4().hex[:12])
    output.mkdir(exist_ok=False)

    def load(filename):
        nonlocal reference, grid
        path = (folder / filename).resolve()
        if path.parent != folder:
            raise ValueError("Los diagnósticos deben estar en la misma carpeta que metadatos.json.")
        dataset = gdal.Open(str(path))
        if dataset is None:
            raise ValueError("No se puede leer: " + str(path))
        identity = (dataset.RasterXSize, dataset.RasterYSize,
                    dataset.GetGeoTransform(), dataset.GetProjection())
        if reference is None:
            reference = identity
            width, height, transform, projection = identity
            if width != height or transform[1:3] != (RESOLUTION, 0.0) or transform[4:] != (0.0, -RESOLUTION):
                raise ValueError("La cuadrícula no corresponde a resultados de este complemento.")
            crs = osr.SpatialReference(wkt=projection)
            crs.AutoIdentifyEPSG()
            epsg = int(crs.GetAuthorityCode(None))
            bounds = (transform[0], transform[3] - height * RESOLUTION,
                      transform[0] + width * RESOLUTION, transform[3])
            positions = (np.arange(width) + 0.5 - width / 2) * RESOLUTION
            radius = float(metadata["parameters"]["radius"])
            aoi = positions[None, :] ** 2 + positions[:, None] ** 2 <= radius ** 2
            grid = (epsg, bounds, width, None, aoi)
        elif identity != reference:
            raise ValueError("Las capas de diagnóstico no comparten cuadrícula y CRS.")
        result = dataset.GetRasterBand(1).ReadAsArray().astype(np.float32)
        nodata = dataset.GetRasterBand(1).GetNoDataValue()
        if nodata is not None:
            result[result == nodata] = np.nan
        return result

    try:
        repaired_records, composites, counts = [], [], []
        corrections = 0
        for period in ("before", "after"):
            arrays = []
            for selected in metadata[period]["selected"]:
                record = next((record for record in metadata["diagnostics"]
                               if record["id"] == selected["id"]), None)
                if record is None:
                    raise ValueError("Falta diagnóstico para la imagen " + selected["id"])
                red = load(record["files"]["rojo"])
                nir = load(record["files"]["NIR"])
                scl = load(record["files"]["SCL"])
                aoi = grid[4]
                for name, array in (("red", red), ("nir", nir)):
                    info = selected["assets"][name]
                    correction = stored_offset_correction(info)
                    array += correction
                    corrections += int(correction != 0)
                    if correction != 0:
                        info["previous_scale_offset"] = list(info["scale_offset"])
                        info["scale_offset"][1] = 0.0
                    record["assets"][name] = dict(info)
                ndvi = compute_ndvi(red, nir, scl, aoi)
                arrays.append(ndvi)
                selected["valid_fraction"] = float(np.count_nonzero(np.isfinite(ndvi)) / np.count_nonzero(aoi))
                codes = exclusion_map(red, nir, scl, aoi)
                selected["exclusions"] = exclusion_summary(codes, aoi)
                record["exclusions"] = selected["exclusions"]
                for name, array in (("rojo", red), ("NIR", nir), ("SCL", scl), ("exclusion", codes)):
                    filename = Path(record["files"][name]).name
                    save_raster(output / filename, array, grid)
                    record["files"][name] = filename
                repaired_records.append(record)
            composite, observations = median_composite(arrays)
            observations[~grid[4]] = np.nan
            composites.append(composite)
            counts.append(observations)
        difference = composites[1] - composites[0]
        valid = np.isfinite(difference)
        if not np.any(valid):
            raise ValueError("No hay datos válidos comunes después de la reparación.")
        results = []
        for name, array in (("ndvi_1.tif", composites[0]), ("ndvi_2.tif", composites[1]),
                            ("cambio_ndvi.tif", difference), ("observaciones_1.tif", counts[0]),
                            ("observaciones_2.tif", counts[1])):
            path = output / name
            save_raster(path, array, grid)
            results.append(path)
        metadata["diagnostics"] = repaired_records
        metadata["repair"] = {"version": "0.1.4", "bands_corrected": corrections,
                              "reason": "Remove duplicate offset on already harmonized Earth Search COGs"}
        metadata["statistics"] = {
            "common_valid_pixels": int(np.count_nonzero(valid)),
            "common_valid_fraction": float(np.count_nonzero(valid) / np.count_nonzero(grid[4])),
            "mean_change": float(np.mean(difference[valid])),
            "median_change": float(np.median(difference[valid])),
        }
        (output / "metadatos.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
        return output, results, metadata
    except Exception:
        shutil.rmtree(output, ignore_errors=True)
        raise


def repair_results_dialog():
    filename, _ = QFileDialog.getOpenFileName(iface.mainWindow(), "Reparar resultados NDVI", "", "Metadatos (metadatos.json)")
    if not filename:
        return
    try:
        output, results, metadata = repair_saved_results(filename)
        reporter = NDVITask(0, 0, {})
        reporter.output, reporter.results, reporter.metadata = output, results, metadata
        reporter.diagnostic_records = metadata["diagnostics"]
        reporter.finished(True)
    except Exception as error:
        iface.messageBar().pushCritical("Reparar NDVI", str(error))


class NDVIDialog(QDialog):
    def __init__(self):
        super().__init__(iface.mainWindow())
        self.setWindowTitle("Cambio de NDVI · Sentinel-2")
        form = QFormLayout(self)
        today = QDate.currentDate()
        self.start1 = QDateEdit(today.addMonths(-2))
        self.end1 = QDateEdit(today.addMonths(-2).addDays(14))
        self.start2 = QDateEdit(today.addMonths(-1))
        self.end2 = QDateEdit(today.addMonths(-1).addDays(14))
        for widget in (self.start1, self.end1, self.start2, self.end2):
            widget.setCalendarPopup(True)
            widget.setDisplayFormat("yyyy-MM-dd")
            widget.setMinimumDate(QDate(2015, 6, 23))
            widget.setMaximumDate(today)
        form.addRow("Primer intervalo · desde:", self.start1)
        form.addRow("Primer intervalo · hasta (incluido):", self.end1)
        form.addRow("Segundo intervalo · desde:", self.start2)
        form.addRow("Segundo intervalo · hasta (incluido):", self.end2)
        self.count1, self.count2 = QSpinBox(), QSpinBox()
        for widget in (self.count1, self.count2):
            widget.setRange(1, 10)
            widget.setValue(1)
        form.addRow("Imágenes del primer intervalo:", self.count1)
        form.addRow("Imágenes del segundo intervalo:", self.count2)
        self.radius = QSpinBox()
        self.radius.setRange(50, 5000)
        self.radius.setSingleStep(50)
        self.radius.setValue(1000)
        self.radius.setSuffix(" m")
        form.addRow("Radio de análisis alrededor del clic:", self.radius)
        self.min_valid = QSpinBox()
        self.min_valid.setRange(0, 100)
        self.min_valid.setValue(0)
        self.min_valid.setSuffix(" %")
        self.min_valid.setSpecialValueText("Desactivado")
        self.min_valid.setToolTip(
            "Filtro adicional de área local válida. No es la nubosidad de la escena. "
            "Con 0 se enmascaran nubes igualmente y se requiere algún píxel válido."
        )
        form.addRow("Mínimo de área válida local (opcional):", self.min_valid)
        info = QLabel(
            "Nubosidad de escena ≤20 % (al menos 80 % libre de nubes).\n"
            "Los píxeles con nubes, sombras o nieve se excluyen según SCL.\n"
            "El filtro adicional de área válida local es opcional.\n"
            "Se combinan las imágenes mediante la mediana del NDVI.\n"
            "La diferencia es NDVI del segundo intervalo − NDVI del primero."
        )
        info.setWordWrap(True)
        form.addRow(info)
        self.directory = QLineEdit(str(Path.home()))
        browse = QPushButton("Elegir…")
        row = QHBoxLayout()
        row.addWidget(self.directory)
        row.addWidget(browse)
        form.addRow("Carpeta de resultados:", row)
        browse.clicked.connect(self.choose_directory)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)

    def choose_directory(self):
        directory = QFileDialog.getExistingDirectory(self, "Guardar resultados", self.directory.text())
        if directory:
            self.directory.setText(directory)

    def parameters(self):
        start1 = self.start1.date().toString("yyyy-MM-dd")
        end1 = self.end1.date().toString("yyyy-MM-dd")
        start2 = self.start2.date().toString("yyyy-MM-dd")
        end2 = self.end2.date().toString("yyyy-MM-dd")
        if start1 > end1 or start2 > end2:
            raise ValueError("Cada intervalo debe terminar después de su inicio o el mismo día.")
        if start2 <= end1:
            raise ValueError("El segundo intervalo debe comenzar después de terminar el primero.")
        directory = Path(self.directory.text()).expanduser()
        if not directory.is_dir():
            raise ValueError("Selecciona una carpeta existente.")
        return {"start1": start1, "end1": end1, "start2": start2, "end2": end2,
                "count1": self.count1.value(), "count2": self.count2.value(),
                "min_valid_percent": self.min_valid.value(),
                "radius": self.radius.value(), "directory": str(directory)}


class NDVITask(QgsTask):
    status_text = pyqtSignal(str)

    def __init__(self, lon, lat, parameters):
        super().__init__("Comparación NDVI Sentinel-2", QgsTask.CanCancel)
        self.lon, self.lat, self.parameters = lon, lat, parameters
        self.error = None
        self.notify_results = True
        self.output = None
        self.results = []
        self.metadata = None
        self.diagnostic_records = []

    def check_cancel(self):
        if self.isCanceled():
            raise RuntimeError("Operación cancelada.")

    def select_composite(self, label, start_date, end_date, count, grid, excluded):
        self.status_text.emit("Buscando imágenes: " + start_date + " a " + end_date + "…")
        items = search_items(grid[3], start_date, end_date, self.check_cancel)
        arrays, accepted, rejected = [], [], []
        acquisitions = set()
        tested = 0
        for item in items:
            if item["id"] in excluded or acquisition_key(item) in acquisitions:
                continue
            if tested >= MAX_CANDIDATES:
                break
            tested += 1
            self.check_cancel()
            self.status_text.emit("%s: evaluando %s (%d/%d)" %
                                  (label, item["id"], len(accepted), count))
            try:
                red, red_info = read_asset(item, "red", "B04", grid)
                self.check_cancel()
                nir, nir_info = read_asset(item, "nir", "B08", grid)
                self.check_cancel()
                scl, scl_info = read_asset(item, "scl", "SCL", grid, categorical=True)
                ndvi = compute_ndvi(red, nir, scl, grid[4])
                valid_fraction = float(np.count_nonzero(np.isfinite(ndvi))) / np.count_nonzero(grid[4])
                min_valid = self.parameters.get("min_valid_percent", 0) / 100.0
                codes = exclusion_map(red, nir, scl, grid[4])
                summary = exclusion_summary(codes, grid[4])
                # Conservar la primera candidata y cada imagen aceptada.
                if tested == 1 or (valid_fraction > 0 and valid_fraction >= min_valid):
                    if self.output is not None:
                        prefix = ("periodo1" if label == "Primer intervalo" else "periodo2") + "_%02d" % tested
                        files = {}
                        for name, array in (("SCL", scl), ("rojo", red), ("NIR", nir), ("exclusion", codes)):
                            filename = "diagnostico_" + prefix + "_" + name + ".tif"
                            clipped = np.where(grid[4], array, np.nan)
                            save_raster(self.output / filename, clipped, grid)
                            files[name] = filename
                        self.diagnostic_records.append({"id": item["id"], "period": label,
                                                        "files": files, "exclusions": summary,
                                                        "assets": {"red": red_info, "nir": nir_info}})
                if valid_fraction == 0 or valid_fraction < min_valid:
                    clear_fraction = float(np.count_nonzero(
                        grid[4] & np.isin(scl, CLEAR_SCL)
                    )) / np.count_nonzero(grid[4])
                    spectral_fraction = float(np.count_nonzero(
                        grid[4] & np.isfinite(red) & np.isfinite(nir)
                        & (red >= 0) & (nir >= 0) & ((red + nir) > 0)
                    )) / np.count_nonzero(grid[4])
                    reason = (
                        "%s: NDVI válido %.1f %%, SCL despejado %.1f %%, "
                        "bandas válidas %.1f %% (mínimo local configurado %.1f %%)" %
                        (item["id"], 100 * valid_fraction, 100 * clear_fraction,
                         100 * spectral_fraction, 100 * min_valid)
                    )
                    rejected.append({"id": item["id"], "reason": reason,
                                     "valid_fraction": valid_fraction,
                                     "clear_fraction": clear_fraction,
                                     "spectral_fraction": spectral_fraction,
                                     "exclusions": summary})
                    continue
            except Exception as error:
                self.check_cancel()
                rejected.append({"id": item["id"], "reason": str(error)})
                continue
            arrays.append(ndvi)
            acquisitions.add(acquisition_key(item))
            accepted.append({"id": item["id"], "datetime": item["properties"]["datetime"],
                             "acquisition": acquisition_key(item),
                             "cloud_cover_percent": item["properties"]["eo:cloud_cover"],
                             "valid_fraction": valid_fraction,
                             "exclusions": summary,
                             "assets": {"red": red_info, "nir": nir_info, "scl": scl_info}})
            if len(arrays) == count:
                break
        if len(arrays) != count:
            reasons = "; ".join(entry["reason"] for entry in rejected[:3])
            raise RuntimeError(
                "%s: se solicitaron %d imágenes y solo se aceptaron %d tras evaluar %d. "
                "Amplía el intervalo, reduce el radio o pide menos imágenes. %s" %
                (label, count, len(arrays), tested, reasons)
            )
        composite, counts = median_composite(arrays)
        counts[~grid[4]] = np.nan
        return composite, counts, {"start_date": start_date, "end_date": end_date,
                                   "selected": accepted, "rejected": rejected}

    def run(self):
        options = {"GDAL_HTTP_TIMEOUT": "30", "GDAL_HTTP_MAX_RETRY": "2",
                   "GDAL_DISABLE_READDIR_ON_OPEN": "EMPTY_DIR"}
        previous = {}
        try:
            if hasattr(gdal, "SetThreadLocalConfigOption"):
                for key, value in options.items():
                    previous[key] = gdal.GetConfigOption(key)
                    gdal.SetThreadLocalConfigOption(key, value)
            p = self.parameters
            grid = make_grid(self.lon, self.lat, p["radius"])
            self.output = Path(p["directory"]) / ("NDVI_" + uuid.uuid4().hex[:12])
            self.output.mkdir(exist_ok=False)
            before, count_before, meta_before = self.select_composite(
                "Primer intervalo", p["start1"], p["end1"], p["count1"], grid, set()
            )
            self.setProgress(45)
            # Evita usar la misma adquisición para representar ambas fechas.
            excluded = {item["id"] for item in meta_before["selected"]}
            after, count_after, meta_after = self.select_composite(
                "Segundo intervalo", p["start2"], p["end2"], p["count2"], grid, excluded
            )
            self.setProgress(90)
            self.check_cancel()
            difference = after - before
            if not np.any(np.isfinite(difference)):
                raise RuntimeError("No hay píxeles válidos comunes entre ambas fechas.")
            rasters = [("ndvi_1.tif", before), ("ndvi_2.tif", after),
                       ("cambio_ndvi.tif", difference),
                       ("observaciones_1.tif", count_before),
                       ("observaciones_2.tif", count_after)]
            for filename, array in rasters:
                self.check_cancel()
                path = self.output / filename
                save_raster(path, array, grid)
                self.results.append(path)
            valid = np.isfinite(difference)
            self.metadata = {
                "source": STAC_URL, "collection": COLLECTION,
                "point_wgs84": [self.lon, self.lat], "parameters": p,
                "epsg": grid[0], "resolution_m": RESOLUTION,
                "composite": "median of per-image NDVI", "difference": "second minus first",
                "clear_scl_classes": list(CLEAR_SCL), "max_scene_cloud_percent": 20,
                "min_local_valid_fraction_per_image": p.get("min_valid_percent", 0) / 100.0,
                "before": meta_before, "after": meta_after,
                "diagnostics": self.diagnostic_records,
                "statistics": {
                    "common_valid_pixels": int(np.count_nonzero(valid)),
                    "common_valid_fraction": float(np.count_nonzero(valid) / np.count_nonzero(grid[4])),
                    "mean_change": float(np.mean(difference[valid])),
                    "median_change": float(np.median(difference[valid])),
                },
            }
            (self.output / "metadatos.json").write_text(
                json.dumps(self.metadata, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            self.setProgress(100)
            return True
        except Exception:
            self.error = traceback.format_exc()
            if self.output is not None:
                if self.diagnostic_records and not self.isCanceled():
                    (self.output / "diagnostico_error.json").write_text(json.dumps({
                        "parameters": self.parameters, "error": self.error,
                        "diagnostics": self.diagnostic_records,
                    }, ensure_ascii=False, indent=2), encoding="utf-8")
                else:
                    shutil.rmtree(self.output, ignore_errors=True)
            return False
        finally:
            for key, value in previous.items():
                gdal.SetThreadLocalConfigOption(key, value)

    def finished(self, success):
        if not self.notify_results:
            return
        if not success:
            if self.isCanceled():
                iface.messageBar().pushInfo("NDVI", "Operación cancelada.")
            else:
                from qgis.core import QgsMessageLog
                QgsMessageLog.logMessage(self.error or "Error desconocido", "NDVI Sentinel", Qgis.Critical)
                message = (self.error or "Error desconocido").strip().splitlines()[-1]
                if self.diagnostic_records and self.output is not None:
                    message += " Diagnóstico guardado en: " + str(self.output)
                iface.messageBar().pushCritical("NDVI", message)
            return
        # Los recuentos quedan debajo y el mapa de cambio encima.
        for path in sorted(self.results, key=lambda p: (
            2 if p.name == "cambio_ndvi.tif" else 1 if p.name.startswith("ndvi_") else 0
        )):
            layer = QgsRasterLayer(str(path), path.stem)
            if layer.isValid():
                if path.name in ("ndvi_1.tif", "ndvi_2.tif", "cambio_ndvi.tif"):
                    style_ndvi(layer, difference=path.name == "cambio_ndvi.tif")
                QgsProject.instance().addMapLayer(layer)
        stats = self.metadata["statistics"]
        # Cargar las razones de exclusión debajo del mapa principal.
        for record in self.diagnostic_records:
            path = self.output / record["files"]["exclusion"]
            layer = QgsRasterLayer(str(path), path.stem)
            if layer.isValid():
                style_exclusion(layer)
                QgsProject.instance().addMapLayer(layer, False)
                node = QgsProject.instance().layerTreeRoot().addLayer(layer)
                node.setItemVisibilityChecked(False)
        iface.messageBar().pushSuccess(
            "NDVI", "Cambio medio: %.3f; área válida común: %.1f %%. Resultados: %s" %
            (stats["mean_change"], 100 * stats["common_valid_fraction"], self.output)
        )


def style_exclusion(layer):
    colors = {1: "#228b22", 2: "#808080", 3: "#a9a9a9", 4: "#654321",
              5: "#a0522d", 6: "#ffa500", 7: "#ffffff", 8: "#00ffff",
              9: "#ff00ff", 10: "#ff0000", 11: "#000000"}
    shader = QgsColorRampShader()
    shader.setColorRampType(QgsColorRampShader.Exact)
    shader.setColorRampItemList([
        QgsColorRampShader.ColorRampItem(code, QColor(colors[code]), label)
        for code, label in EXCLUSION_LABELS.items()
    ])
    raster_shader = QgsRasterShader()
    raster_shader.setRasterShaderFunction(shader)
    layer.setRenderer(QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, raster_shader))


def style_ndvi(layer, difference=False):
    shader = QgsColorRampShader()
    shader.setColorRampType(QgsColorRampShader.Interpolated)
    if difference:
        stops = [(-2, "#b2182b", "Disminución"), (0, "#f7f7f7", "Sin cambio"),
                 (2, "#1a9850", "Aumento")]
    else:
        stops = [(-1, "#2166ac", "−1"), (0, "#d9c39c", "0"), (1, "#006837", "1")]
    shader.setColorRampItemList([
        QgsColorRampShader.ColorRampItem(value, QColor(color), label)
        for value, color, label in stops
    ])
    raster_shader = QgsRasterShader()
    raster_shader.setRasterShaderFunction(shader)
    renderer = QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, raster_shader)
    renderer.setClassificationMin(-2 if difference else -1)
    renderer.setClassificationMax(2 if difference else 1)
    layer.setRenderer(renderer)
    layer.triggerRepaint()


class NDVIClickTool(QgsMapToolEmitPoint):
    def __init__(self):
        super().__init__(iface.mapCanvas())
        self.setCursor(Qt.CrossCursor)
        self.canvasClicked.connect(self.clicked)
        self.task = None
        self.task_token = None
        self.progress_dialog = None

    def clicked(self, point, button):
        if button != Qt.LeftButton:
            return
        task = self.live_task()
        if task is not None and task.status() in (
            QgsTask.Queued, QgsTask.Running, QgsTask.OnHold
        ):
            iface.messageBar().pushWarning("NDVI", "Ya hay un análisis en curso.")
            return
        dialog = NDVIDialog()
        if dialog.exec_() != QDialog.Accepted:
            return
        try:
            parameters = dialog.parameters()
            transform = QgsCoordinateTransform(
                self.canvas().mapSettings().destinationCrs(),
                QgsCoordinateReferenceSystem("EPSG:4326"), QgsProject.instance(),
            )
            geographic = transform.transform(point)
            self.task = NDVITask(geographic.x(), geographic.y(), parameters)
            self.task_token = uuid.uuid4().hex
        except Exception as error:
            iface.messageBar().pushWarning("NDVI", str(error))
            return
        progress = QProgressDialog("Consultando Sentinel-2…", "Cancelar", 0, 100,
                                   iface.mainWindow())
        progress.setWindowTitle("Comparación NDVI")
        progress.setAutoClose(False)
        progress.setAutoReset(False)
        token = self.task_token
        # No conectar canceled directamente a un QgsTask propiedad de QGIS:
        # QGIS puede destruirlo mientras el diálogo aún está vivo.
        progress.canceled.connect(partial(self.cancel_task, token))
        self.task.status_text.connect(partial(self.update_label, token))
        self.task.progressChanged.connect(partial(self.update_progress, token))
        self.task.taskCompleted.connect(partial(self.task_done, token))
        self.task.taskTerminated.connect(partial(self.task_done, token))
        self.task.destroyed.connect(partial(self.task_done, token))
        self.progress_dialog = progress
        progress.show()
        QgsApplication.taskManager().addTask(self.task)

    def live_task(self):
        task = self.task
        if task is not None and sip.isdeleted(task):
            self.task_done(self.task_token)
            return None
        return task

    def cancel_task(self, token, *unused):
        if token != self.task_token:
            return
        task = self.live_task()
        if task is not None:
            task.cancel()

    def update_label(self, token, text):
        progress = self.progress_dialog
        if token == self.task_token and progress is not None and not sip.isdeleted(progress):
            progress.setLabelText(text)

    def update_progress(self, token, value):
        progress = self.progress_dialog
        if token == self.task_token and progress is not None and not sip.isdeleted(progress):
            progress.setValue(int(value))

    def task_done(self, token, *unused):
        if token != self.task_token:
            return
        # Liberar la referencia ANTES de cerrar el diálogo evita cancelaciones
        # tardías sobre el objeto C++ ya finalizado o eliminado.
        self.task = None
        self.task_token = None
        progress = self.progress_dialog
        self.progress_dialog = None
        if progress is not None and not sip.isdeleted(progress):
            progress.blockSignals(True)
            progress.close()
            progress.deleteLater()

    def shutdown(self):
        token = self.task_token
        task = self.live_task()
        if task is not None:
            task.notify_results = False
            task.cancel()
        self.task_done(token)
