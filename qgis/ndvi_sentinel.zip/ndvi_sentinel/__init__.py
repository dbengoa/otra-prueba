"""Punto de entrada del complemento NDVI Sentinel."""


def classFactory(iface):
    from .plugin import NDVISentinelPlugin
    return NDVISentinelPlugin(iface)
