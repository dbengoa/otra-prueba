"""Registro de menú, botón y ciclo de vida del complemento."""

from pathlib import Path

from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction
from qgis.core import Qgis, QgsMessageLog


class NDVISentinelPlugin:
    MENU = "&NDVI Sentinel"

    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.repair_action = None
        self.tool = None
        self.previous_tool = None

    def initGui(self):
        icon = QIcon(str(Path(__file__).with_name("icon.svg")))
        self.action = QAction(icon, "Comparar NDVI Sentinel-2", self.iface.mainWindow())
        self.action.setCheckable(True)
        self.action.setToolTip("Haz clic en el mapa y elige dos intervalos de fechas")
        self.action.triggered.connect(self.toggle_tool)
        self.iface.addPluginToMenu(self.MENU, self.action)
        self.iface.addToolBarIcon(self.action)
        self.repair_action = QAction("Reparar resultados guardados…", self.iface.mainWindow())
        self.repair_action.triggered.connect(self.repair_results)
        self.iface.addPluginToMenu(self.MENU, self.repair_action)
        self.iface.mapCanvas().mapToolSet.connect(self.sync_action)

    def repair_results(self, *unused):
        from .analysis import repair_results_dialog
        repair_results_dialog()

    def toggle_tool(self, checked):
        canvas = self.iface.mapCanvas()
        if not checked:
            if self.tool is not None and canvas.mapTool() is self.tool:
                self.restore_tool()
            return
        try:
            if self.tool is None:
                # Cargar GDAL/NumPy solo al activar la función.
                from .analysis import NDVIClickTool
                self.tool = NDVIClickTool()
        except Exception as error:
            self.action.setChecked(False)
            QgsMessageLog.logMessage(str(error), "NDVI Sentinel", Qgis.Critical)
            self.iface.messageBar().pushCritical(
                "NDVI Sentinel", "No se pudo cargar el complemento. "
                "Comprueba que QGIS dispone de NumPy y GDAL: " + str(error)
            )
            return
        if canvas.mapTool() is not self.tool:
            self.previous_tool = canvas.mapTool()
        canvas.setMapTool(self.tool)
        self.iface.messageBar().pushInfo(
            "NDVI Sentinel", "Haz clic para elegir intervalos, imágenes y radio de análisis."
        )

    def sync_action(self, *args):
        if self.action is not None:
            self.action.setChecked(self.tool is not None and
                                   self.iface.mapCanvas().mapTool() is self.tool)

    def restore_tool(self):
        canvas = self.iface.mapCanvas()
        if self.previous_tool is not None:
            try:
                canvas.setMapTool(self.previous_tool)
                return
            except RuntimeError:
                self.previous_tool = None
        canvas.unsetMapTool(self.tool)
        self.iface.actionPan().trigger()

    def unload(self):
        canvas = self.iface.mapCanvas()
        try:
            canvas.mapToolSet.disconnect(self.sync_action)
        except (TypeError, RuntimeError):
            pass
        if self.tool is not None:
            self.tool.shutdown()
            if canvas.mapTool() is self.tool:
                self.restore_tool()
            self.tool.deleteLater()
            self.tool = None
        if self.action is not None:
            self.iface.removePluginMenu(self.MENU, self.action)
            self.iface.removeToolBarIcon(self.action)
            self.action.deleteLater()
            self.action = None
        if self.repair_action is not None:
            self.iface.removePluginMenu(self.MENU, self.repair_action)
            self.repair_action.deleteLater()
            self.repair_action = None
        self.previous_tool = None
