# Comparar NDVI de Sentinel-2 desde un clic en QGIS

Complemento NDVI Sentinel 0.1.1. Pensado para QGIS 3.22–3.x con GDAL 3 y NumPy,
disponibles normalmente en la instalación de QGIS. No necesitas Sentinel Hub
ni proporcionar una clave de API: consulta el catálogo público Earth Search
de Element 84, colección `sentinel-2-l2a`, y lee sus imágenes COG por HTTPS.

## Uso

1. Abre un proyecto de QGIS y sitúa el mapa en la zona de interés.
2. Instala `ndvi_sentinel.zip` desde **Complementos → Administrar e instalar complementos → Instalar a partir de ZIP**.
3. Activa **NDVI Sentinel** y pulsa su botón de la barra de herramientas o **Complementos → NDVI Sentinel → Comparar NDVI Sentinel-2**.
4. Haz clic en el mapa. Aparecerá el diálogo de configuración.
5. Selecciona dos intervalos cronológicos que no se solapen, el número de
   imágenes de cada intervalo, el radio y una carpeta de resultados.
6. Acepta. El análisis se ejecuta en segundo plano y permite cancelar.

El radio inicial es 1 km, configurable entre 50 m y 5 km. Las fechas finales
son inclusivas y se consultan como días UTC del catálogo. Para abandonar la
herramienta, selecciona la herramienta habitual de desplazamiento del mapa.

## Qué calcula

- Busca escenas con **nubosidad de catálogo ≤20 %**.
- Lee rojo B04, infrarrojo cercano B08 y clasificación SCL.
- Reproyecta las bandas a una cuadrícula común UTM de 10 m. Usa interpolación
  bilineal para las bandas espectrales y vecino más próximo para SCL.
- Aplica la escala y el offset radiométricos. Esto evita errores al comparar
  imágenes anteriores y posteriores al cambio de baseline de Sentinel-2.
- Solo acepta píxeles SCL de vegetación, suelo sin vegetación o agua (4, 5, 6).
  Excluye nubes, cirros, sombras, nieve, píxeles sin clasificar y no-data.
- El **mínimo de área válida dentro del círculo** es un filtro adicional
  configurable de 0 a 100 %, desactivado inicialmente. No se confunde con
  el requisito de un 80 % libre de nubes de la escena completa. Aunque esté
  desactivado, siempre excluye los píxeles no válidos y exige algún dato válido.
- Calcula `NDVI = (B08 − B04) / (B08 + B04)` para cada imagen y después toma la
  mediana por píxel de las imágenes de cada intervalo.
- Calcula `cambio = NDVI_segundo_intervalo − NDVI_primer_intervalo` únicamente
  donde ambos resultados tienen datos válidos.

Selecciona primero las escenas más próximas al centro de cada intervalo;
en caso de empate, prioriza menor nubosidad. No cuenta varias teselas del
mismo paso como varias adquisiciones. Evalúa como máximo 50 candidatas por
intervalo. Si no logra reunir exactamente las imágenes solicitadas, muestra
un error; no reduce silenciosamente el número ni relaja el filtro de nubes.
Si rechaza escenas por falta de cobertura válida, muestra sus porcentajes
de NDVI válido, SCL despejado y bandas espectrales válidas.

## Actualizar desde 0.1.0

Desinstala NDVI Sentinel desde el administrador de complementos, instala el
ZIP 0.1.1 y reinicia QGIS para descargar de memoria los módulos anteriores.
El aviso de intervalos solapados se resuelve haciendo que el segundo intervalo
comience después del último día del primero.

## Resultados

Cada ejecución crea una subcarpeta nueva y no sobrescribe resultados:

- `ndvi_1.tif` y `ndvi_2.tif`: NDVI compuesto de cada intervalo.
- `cambio_ndvi.tif`: diferencia. Rojo indica descenso y verde aumento.
- `observaciones_1.tif` y `observaciones_2.tif`: número de imágenes válidas
  por píxel utilizadas para cada compuesto, para revisar su soporte temporal.
- `metadatos.json`: parámetros, escenas y fechas reales, enlaces de origen,
  filtros, correcciones radiométricas y estadísticas de cambio.

Los GeoTIFF se añaden al proyecto. Fuera del círculo y donde no hay datos
válidos se utiliza no-data. Las zonas restantes pueden tener menos del
número solicitado de observaciones por píxel: consulta las capas de recuento.

## Límites y acceso

Necesita acceso HTTPS a `earth-search.aws.element84.com` y a los destinos de
los assets que devuelva el catálogo, habitualmente los buckets públicos
Sentinel en Amazon S3. Mantiene la verificación TLS. Si falla, consulta el
panel **Mensajes de registro**, pestaña **NDVI Sentinel**, para ver el detalle.

El 80 % es un criterio basado en metadatos y clasificación automática, no una
garantía visual absoluta. Una bajada de NDVI puede deberse a estacionalidad,
cosecha, humedad o diferencias de observación; el resultado mide el cambio
del índice, no clasifica automáticamente una pérdida de vegetación.

En el entorno de preparación se ha validado la sintaxis y los cálculos con
datos sintéticos. No se ha ejecutado dentro de QGIS ni validado una descarga
real: QGIS/GDAL no están instalados y el acceso al catálogo está bloqueado.
